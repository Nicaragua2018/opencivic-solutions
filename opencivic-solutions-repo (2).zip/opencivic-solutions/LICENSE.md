# Licencias de OpenCivic Solutions

OpenCivic Solutions usa el mismo esquema de licencias que [Decidim](https://docs.decidim.org/en/v0.31/whitepaper/what-is-decidim): una licencia para el código, otra para el contenido y otra para los datos.

| Qué cubre | Licencia | Identificador SPDX | Texto oficial |
| --- | --- | --- | --- |
| Código fuente de todos los repositorios de OpenCivic | GNU Affero General Public License, versión 3 | `AGPL-3.0-or-later` | <https://www.gnu.org/licenses/agpl-3.0.html> |
| Contenido: textos, documentos, ilustraciones, diseño y plantillas | Creative Commons Atribución-CompartirIgual 4.0 Internacional | `CC-BY-SA-4.0` | <https://creativecommons.org/licenses/by-sa/4.0/legalcode.es> |
| Bases de datos abiertas publicadas por OpenCivic | Open Database License 1.0 | `ODbL-1.0` | <https://opendatacommons.org/licenses/odbl/1-0/> |

## Qué significa en la práctica

- **Código (AGPL-3.0):** puedes usarlo, estudiarlo, modificarlo y redistribuirlo. Si distribuyes una versión modificada, o la ofreces a otras personas como servicio a través de una red, debes publicar su código fuente con la misma licencia.
- **Contenido (CC BY-SA 4.0):** puedes copiarlo, traducirlo y adaptarlo, también con fines comerciales, siempre que cites a OpenCivic Solutions, enlaces a la licencia, indiques si hiciste cambios y compartas tus adaptaciones con la misma licencia.
- **Datos (ODbL 1.0):** puedes usar, adaptar y combinar las bases de datos, citando la fuente; si publicas una base de datos derivada, debe seguir abierta con la misma licencia.

## Nombre y logo

Las licencias abiertas no autorizan a usar el nombre ni el logo de OpenCivic para hacerse pasar por la organización ni para sugerir su respaldo. Puedes mostrarlos para referirte a OpenCivic o a su trabajo. Esto protege a la comunidad frente a suplantaciones.

## Contenido de terceros

Algunos archivos pueden incluir material de terceros con su propia licencia. En ese caso se indica junto al archivo y prevalece esa licencia.

> [!NOTE]
> Al crear cada repositorio en GitHub se añade el texto completo de la AGPL-3.0 en un archivo `LICENSE` (GitHub lo ofrece como plantilla), y cada archivo de código puede llevar la cabecera `SPDX-License-Identifier: AGPL-3.0-or-later`.

<sub>Esto es información, no asesoría legal. Antes de publicar, conviene que una persona con formación jurídica revise la elección de versiones («solo la 3» o «la 3 o posterior»).</sub>
