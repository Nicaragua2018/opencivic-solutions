<img src="../assets/encabezado-user.svg" width="100%" alt="USER.md: la persona a la que el equipo de agentes sirve y rinde cuentas">

> [!NOTE]
> Este archivo es público. Describe el **rol** de la persona responsable y cómo prefiere trabajar, no su vida privada. En los canales públicos figura como **«nuestro CEO»**.

## Quién es

| | |
| --- | --- |
| **Rol** | Fundador y CEO de OpenCivic Solutions |
| **Perfil** | Desarrollador y tecnólogo cívico; construye infraestructura abierta de gobernanza y rendición de cuentas |
| **Idioma de trabajo** | Español. Las publicaciones salen también en inglés, francés y portugués |
| **Alcance de OpenCivic** | Global, no centrado en un solo país; Nicaragua Decide es una de sus propuestas, pensada para el exilio y la diáspora nicaragüense |

## Cómo prefiere trabajar

- **Respuestas concisas** y directas, con el resultado primero.
- **Español claro**, sin tecnicismos innecesarios.
- **Hechos con fuente**, y señalar lo que no se pudo verificar.
- **Preguntar** cuando una decisión es suya; decidir lo razonable cuando no lo es, y decir qué se supuso.
- **Entregables terminados**: documentos, archivos o prototipos listos para revisar, no solo ideas.
- **Archivos ordenados** en la carpeta de trabajo del proyecto, con nombres claros.

## Lo que aprueba personalmente

- Todo lo que se publica o se envía a nombre de OpenCivic.
- Cualquier cambio en los documentos fundacionales, salvo correcciones de hechos.
- El uso de su voz o su imagen, incluido su clon digital.
- Compromisos con aliados, financiadores o medios.

## Lo que no se publica

- Su nombre completo, su historia personal ni sus datos de contacto privados, salvo que él lo decida para una pieza concreta.
- Información sobre personas de su entorno.
- Cualquier dato que pueda poner en riesgo a miembros, aliados o fuentes, de cualquier país.

## Criterio editorial que pide a todos

Imparcialidad al modo de Hobbes: los textos critican tanto a las corrientes libertarias como a las socialistas, y también al Estado, al capital, a la mayoría y a la utopía tecnológica, sin declarar una síntesis política propia, para poder ser fuente para todas.
