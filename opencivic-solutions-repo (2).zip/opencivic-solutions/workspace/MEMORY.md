<img src="../assets/encabezado-memory.svg" width="100%" alt="MEMORY.md: lo que ya se decidió, para no empezar de cero cada vez">

> Cada agente lee este archivo al empezar y lo actualiza al cerrar la sesión: añade las decisiones nuevas arriba, con fecha, y mueve a «Resuelto» lo que ya no está pendiente. Las decisiones sustituidas se tachan, no se borran.

**Última actualización:** 2026-10-08

## Decisiones vigentes

| Fecha | Decisión |
| --- | --- |
| 2026-10-08 | **Dominio oficial:** opencivicsolutions.org. **Correo de contacto y seguridad:** info@opencivicsolutions.org. |
| 2026-10-08 | **Licencias, las mismas que Decidim:** código AGPL-3.0, contenido CC BY-SA 4.0 y datos ODbL 1.0. |
| 2026-10-08 | En la web y en los canales públicos, la persona responsable figura como **«nuestro CEO»**, sin nombre. |
| 2026-10-08 | Política general de **clones digitales**: consentimiento escrito y revocable, etiqueta que nombra persona o rol y proyecto, guion aprobado, nada en vivo, y **registro público**. Vale para el equipo, los proyectos y las organizaciones usuarias. |
| 2026-10-08 | **Estilo de ilustración:** dibujo a mano en tinta y acuarela con la paleta de marca. Sin fotos de archivo, sin símbolos partidarios, sin rostros reconocibles de personas en riesgo, sin imágenes de IA que parezcan fotos. |
| 2026-10-08 | Las fotos reales solo se usan con permiso escrito, sin símbolos partidarios y con pie de lugar, fecha y autoría. |
| 2026-10-08 | Botón de audiencia «Soy parte de una comunidad» sustituido por **«Quiero participar en mi comunidad»**, que es menos ambiguo. |
| 2026-10-08 | **Web principal:** menú de 5 secciones (Por qué existimos, Proyectos, Recursos, Blog, Únete) y pie de confianza (Transparencia, Principios, Confianza y seguridad, Prensa, Contacto). Botones fijos de Inicio y Compartir, sin rastreadores de redes. |
| 2026-10-08 | La **guía de seguridad digital** es la puerta de entrada del sitio. |
| 2026-10-08 | **Idiomas:** español, inglés, francés y portugués, con rutas propias y traducción revisada por personas. |
| 2026-10-08 | **Fórmula fundacional:** «Democracia para la soberanía. Competencia verificable para el juicio técnico. Criptografía para la prueba. Constitución para los límites.» Sustituye a ~~«aristocracia para la competencia»~~. |
| 2026-10-08 | El peso adicional (1,3 veces como máximo) se reconoce solo por capacidad técnica y experiencia verificables, ~~no por estar «mejor informado»~~. |
| 2026-10-07 | **Forma legal elegida:** corporación sin fines de lucro en Colorado (EE. UU.) con solicitud 501(c)(3). Estado: en constitución. |
| 2026-10-07 | OpenCivic es **global**; Nicaragua Decide es una de sus propuestas, no su único foco. |
| 2026-10-07 | **Criterio editorial:** imparcialidad al modo de Hobbes, sin declarar una síntesis política propia. |

## Estado de los proyectos

| Proyecto | Fase | Próximo paso |
| --- | --- | --- |
| Observatorio de preparación cuántica de Bitcoin | Especificación · objetivo inicial R2 | Taxonomía de riesgos y repositorio público (Sprint 0) |
| Hash Republic Protocol | Arquitectura v0.1 | Esqueleto del monorepo en GitHub |
| BitCuant | Especificación lista | Confirmar si es independiente de HRP y el mecanismo antisybil del MVP |
| Nicaragua Decide | Idea | Definir alcance con protección de identidad |
| HAD Foundation | Idea | Ficha completa; aclarar siempre que no sustituye asesoría legal |
| Guía de seguridad digital | Borrador v0.1 | Verificar fuentes pendientes, revisión de especialista y traducción |
| Sitio web | Prototipo navegable | Elegir plataforma; lanzamiento el **15 de enero de 2027** |

## Marca

| Elemento | Valor |
| --- | --- |
| Azul cívico | `#0A3880` |
| Amarillo miel | `#F2B00A` (solo para acentos y fondos; nunca texto pequeño sobre blanco) |
| Tinta | `#0F172A` |
| Niebla | `#F4F6FA` |
| Tipografías | Poppins (títulos y nombre), Inter (texto), JetBrains Mono (código y huellas) |
| Logo | Monograma «OS»: hexágono de panal, S azul y dos abejas con estela punteada |
| Archivos | Logo vectorial (12 variantes), iconos y favicon, animación Lottie y plantillas en [`../assets/`](../assets/) y en la carpeta de marca |

## Pendientes

- [ ] Enlaces de los canales oficiales
- [ ] Plataforma del sitio: sitio estático + Ghost para el blog, o solo Ghost
- [ ] Revisión de las traducciones por hablantes nativos
- [ ] Prueba del prototipo con cinco personas, una por público
- [ ] Guía de seguridad: verificar Modo de aislamiento de Apple, cifrado de WhatsApp y línea de Front Line Defenders; añadir organizaciones locales
- [ ] Protocolo de seguridad y política de datos antes de abrir el chatbot o canales públicos
- [ ] Actualizar el sistema de contenido con la política general de clones

## Resuelto

- [x] Dominio y correo institucional (2026-10-08)
- [x] Licencias: AGPL-3.0, CC BY-SA 4.0 y ODbL, como Decidim (2026-10-08)
- [x] Logo vectorial, iconos, favicon, animación Lottie y plantillas de marca (2026-10-08)
- [x] Descripción de HAD Foundation (2026-10-08)
- [x] Manual de marca con estilo de ilustración (2026-10-08)
