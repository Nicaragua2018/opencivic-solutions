<img src="../assets/encabezado-workspace.svg" width="100%" alt="workspace/: el espacio de trabajo del equipo de agentes de OpenCivic">

Esta carpeta es la memoria compartida y el reglamento del equipo de agentes de IA de OpenCivic. Cualquier agente, humano o herramienta que trabaje para OpenCivic la lee antes de empezar.

## Orden de lectura

```mermaid
flowchart LR
    S["1 · SOUL.md<br/><i>por qué y con qué valores</i>"] --> A["2 · AGENT.md<br/><i>quién hace qué y con qué límites</i>"]
    A --> U["3 · USER.md<br/><i>a quién servimos</i>"]
    U --> M["4 · MEMORY.md<br/><i>qué ya está decidido</i>"]
    M --> T(["Tarea"])
    T -. "al cerrar la sesión" .-> M
    classDef f fill:#FFFFFF,stroke:#0A3880,color:#0F172A;
    classDef s fill:#0A3880,stroke:#0A3880,color:#FFFFFF;
    classDef t fill:#FFF3D1,stroke:#F2B00A,color:#0F172A;
    class S s;
    class A,U,M f;
    class T t;
```

Si dos archivos se contradicen, manda el que está más a la izquierda: **SOUL.md** prevalece sobre todo lo demás.

## Cómo fluye una tarea

```mermaid
sequenceDiagram
    autonumber
    participant CEO as Persona responsable (CEO)
    participant AG as Agente CEO
    participant EQ as Agentes especialistas
    participant G as Guardián de la razón de ser
    CEO->>AG: Pide un resultado
    AG->>EQ: Reparte el trabajo
    EQ-->>AG: Borradores con fuentes
    AG->>G: Revisión de dignidad, imparcialidad y fuentes
    G-->>AG: Aprobado o con cambios
    AG->>CEO: Entrega para aprobar
    CEO-->>AG: Aprueba o corrige
    AG->>AG: Publica solo lo aprobado y anota en MEMORY.md
```

## Archivos

| Archivo | Qué contiene | Quién lo cambia |
| --- | --- | --- |
| [`SOUL.md`](SOUL.md) | Razón de ser, valores, voz y lo que nunca se hace | Solo la persona responsable, con registro del cambio |
| [`AGENT.md`](AGENT.md) | Equipo de agentes, herramientas, flujo de aprobación y límites | La persona responsable; los agentes proponen cambios |
| [`USER.md`](USER.md) | Rol, preferencias de trabajo y lo que no se publica | La persona responsable |
| [`MEMORY.md`](MEMORY.md) | Decisiones tomadas, estado de proyectos y pendientes | Los agentes, al cerrar cada sesión; la persona revisa |

> [!WARNING]
> Repositorio público. Aquí no van datos personales, credenciales, enlaces privados, rostros ni identidades de personas en riesgo. Si un agente necesita información sensible para una tarea, la pide en un canal privado y no la escribe en estos archivos.
