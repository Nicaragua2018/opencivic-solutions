<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/banner-oscuro.svg">
  <img alt="OpenCivic Solutions: las instituciones también son tecnología" src="assets/banner-claro.svg" width="100%">
</picture>

<p align="center">
  <img alt="Estado: en construcción abierta" src="https://img.shields.io/badge/estado-construcci%C3%B3n%20abierta-F2B00A?style=flat-square&labelColor=0A3880">
  <img alt="Idiomas: ES, EN, FR, PT" src="https://img.shields.io/badge/idiomas-ES%20%C2%B7%20EN%20%C2%B7%20FR%20%C2%B7%20PT-0A3880?style=flat-square">
  <img alt="Lanzamiento del sitio: 15 de enero de 2027" src="https://img.shields.io/badge/sitio-15%20ene%202027-0A3880?style=flat-square">
  <a href="LICENSE.md"><img alt="Código: AGPL-3.0" src="https://img.shields.io/badge/c%C3%B3digo-AGPL--3.0-0A3880?style=flat-square"></a>
  <a href="LICENSE.md"><img alt="Contenido: CC BY-SA 4.0" src="https://img.shields.io/badge/contenido-CC%20BY--SA%204.0-0A3880?style=flat-square"></a>
</p>

<p align="center">
  <a href="#por-qué-existimos"><b>Por qué existimos</b></a> ·
  <a href="#la-fórmula"><b>La fórmula</b></a> ·
  <a href="#proyectos"><b>Proyectos</b></a> ·
  <a href="#el-espacio-de-trabajo-de-agentes"><b>Agentes</b></a> ·
  <a href="#cómo-contribuir"><b>Contribuir</b></a> ·
  <a href="#principios"><b>Principios</b></a>
</p>

> **English summary.** OpenCivic Solutions builds open, verifiable civic technology: tools to cooperate, deliberate and decide together, for social peace and the common good, never at the expense of anyone's hope, justice or dignity. This repository holds the organization's foundations, brand assets and the workspace of its AI agent team. Full translations are on their way.

<img src="assets/divisor.svg" width="100%" alt="">

## Por qué existimos

**Las instituciones también son tecnología.** Las leyes, los parlamentos, las cooperativas y las elecciones son herramientas que la humanidad inventó para cooperar. Si hemos reinventado las tecnologías con las que producimos, viajamos y nos comunicamos, no hay razón para suponer que llegamos al final de la innovación en las que usamos para participar y gobernarnos.

OpenCivic existe para innovar en esas tecnologías institucionales persiguiendo siempre la **paz social** y el **bien común**, sin pasar nunca por encima de la **esperanza**, la **justicia** ni la **dignidad humana** de ningún individuo ni de ninguna minoría.

> [!IMPORTANT]
> **Regla de interpretación.** Todo documento, producto y decisión de OpenCivic se lee a la luz de esta razón de ser. Ningún objetivo colectivo, ninguna eficiencia técnica y ninguna mayoría justifican cruzar esos límites.

El conocimiento y la tecnología nacen de la cooperación y de la herencia de las generaciones pasadas: son **patrimonio de la humanidad**. Por eso todo lo que hacemos es abierto.

<p align="center">
  <img src="assets/ilustracion-asamblea.jpg" alt="Ilustración dibujada a mano: una comunidad diversa reunida alrededor de una mesa, deliberando frente a un tablero con notas" width="90%">
</p>

## La fórmula

| | Pieza | Su trabajo | Su límite |
| :-: | --- | --- | --- |
| ⬡ | **Democracia** | para la soberanía | El resultado sin ponderar siempre queda a la vista. |
| ⬡ | **Competencia verificable** | para el juicio técnico | El peso adicional es de 1,3 veces como máximo y solo se gana con capacidad técnica y experiencia verificables en un dominio. |
| ⬡ | **Criptografía** | para la prueba | Informes con huella digital y sello de tiempo, que cualquiera puede comprobar. |
| ⬡ | **Constitución** | para los límites | Principios escritos que ninguna mayoría, eficiencia ni objetivo colectivo puede cruzar. |

**Información verificable para todos.** La IA ayuda a encontrar, resumir y trazar las fuentes hasta su origen; la criptografía prueba su integridad. Ninguna de las dos prueba por sí sola que algo sea verdad: la verificación combina procedencia, trazabilidad y contraste de fuentes, y el juicio final es humano.

## Proyectos

Construimos en abierto y decimos en qué fase está cada cosa.

```mermaid
flowchart LR
    OC["OpenCivic Solutions<br/><i>razón de ser · principios · marca</i>"]
    HRP["Hash Republic Protocol<br/><i>consenso verificable</i>"]
    OBS["Observatorio de preparación<br/>cuántica de Bitcoin"]
    BC["BitCuant<br/><i>consultas desde la conversación</i>"]
    ND["Nicaragua Decide<br/><i>exilio y diáspora</i>"]
    HAD["HAD Foundation<br/><i>defensa ágil frente a la deportación</i>"]
    GUIA["Guía de seguridad digital"]
    OC --> HRP --> OBS
    OC --> BC
    OC --> ND
    OC --> HAD
    OC --> GUIA
    classDef base fill:#0A3880,stroke:#0A3880,color:#FFFFFF;
    classDef proj fill:#FFFFFF,stroke:#0A3880,color:#0F172A;
    classDef rec fill:#FFF3D1,stroke:#F2B00A,color:#0F172A;
    class OC base;
    class HRP,OBS,BC,ND,HAD proj;
    class GUIA rec;
```

| Proyecto | Qué es | Fase |
| --- | --- | --- |
| **Observatorio de preparación cuántica de Bitcoin** | Mapa público y de solo lectura de riesgos, propuestas y señales no vinculantes. No gobierna Bitcoin ni sustituye el proceso de BIP. | ![especificación](https://img.shields.io/badge/-especificaci%C3%B3n%20%C2%B7%20objetivo%20R2-0A3880?style=flat-square) |
| **Hash Republic Protocol** | Protocolo abierto de delegación líquida por dominio, reputación con tope, detección de captura e informes canónicos. | ![especificación](https://img.shields.io/badge/-arquitectura%20v0.1-0A3880?style=flat-square) |
| **BitCuant** | Una comunidad conversa y un agente propone consultas breves y trazables. El agente no vota ni decide. | ![especificación](https://img.shields.io/badge/-especificaci%C3%B3n%20lista-0A3880?style=flat-square) |
| **Nicaragua Decide** | Laboratorio de consultas cívicas para el exilio y la diáspora nicaragüense, con protección de identidad. | ![idea](https://img.shields.io/badge/-idea-5A6B85?style=flat-square) |
| **HAD Foundation** | Recursos para una defensa ágil frente a la deportación: documentar la evidencia común y resolver trámites rutinarios que suelen arruinar o alargar un buen caso. No sustituye la asesoría legal. | ![idea](https://img.shields.io/badge/-idea-5A6B85?style=flat-square) |
| **Guía de seguridad digital** | Hábitos prácticos para comunidades en riesgo, con fuentes verificadas. | ![borrador](https://img.shields.io/badge/-borrador%20v0.1-F2B00A?style=flat-square&labelColor=0A3880) |

## El espacio de trabajo de agentes

<p align="center">
  <img src="assets/ilustracion-taller.jpg" alt="Ilustración dibujada a mano: una facilitadora explica un diagrama de hexágonos conectados a personas que toman notas" width="90%">
</p>

OpenCivic trabaja con un equipo de agentes de IA coordinado por un **agente CEO**. Los agentes investigan, redactan y preparan; **una persona aprueba antes de que nada se publique**. La carpeta [`workspace/`](workspace/) contiene lo que cualquier agente debe leer antes de trabajar:

| Archivo | Responde a | Léelo cuando |
| --- | --- | --- |
| [`SOUL.md`](workspace/SOUL.md) | ¿Por qué y con qué valores? | Siempre, primero |
| [`AGENT.md`](workspace/AGENT.md) | ¿Quién hace qué, con qué herramientas y con qué límites? | Antes de cada tarea |
| [`USER.md`](workspace/USER.md) | ¿A quién servimos y cómo prefiere trabajar? | Antes de entregar algo |
| [`MEMORY.md`](workspace/MEMORY.md) | ¿Qué está decidido y qué sigue pendiente? | Al empezar y al cerrar cada sesión |

> [!NOTE]
> Este es un repositorio **público**. Los archivos del espacio de trabajo no contienen datos personales, contraseñas, rostros ni identidades de personas en riesgo, y nunca deben contenerlos.

## Estructura del repositorio

```text
opencivic-solutions/
├── README.md             ← estás aquí
├── LICENSE.md            ← licencias del código, el contenido y los datos
├── assets/               ← logo vectorial, banners e ilustraciones de marca
└── workspace/            ← espacio de trabajo del equipo de agentes
    ├── README.md
    ├── SOUL.md
    ├── AGENT.md
    ├── USER.md
    └── MEMORY.md
```

## Cómo contribuir

Hay lugar para quien programa, investiga, diseña, traduce al inglés, francés o portugués, o enseña.

1. Lee [`workspace/SOUL.md`](workspace/SOUL.md): ahí están los límites que no se negocian.
2. Busca una tarea marcada para principiantes en los repositorios de cada proyecto.
3. Abre un *pull request* con tus fuentes: si una afirmación no se puede verificar, no se publica.

Puedes participar con seudónimo. No compartas en issues ni en *pull requests* información que pueda identificarte a ti o a otras personas en riesgo.

## Principios

<details>
<summary><b>Los 25 principios</b> (haz clic para desplegar)</summary>

1. La identidad no es reputación.
2. La reputación no es soberanía.
3. La delegación no es sumisión.
4. La pericia no es autoridad absoluta.
5. El consenso no es coerción.
6. Las señales no son votos vinculantes.
7. La síntesis de IA no es ley.
8. La auditoría protege la delegación.
9. La competencia puede guiar el consenso, pero no poseerlo.
10. La comunidad puede delegar juicio, pero nunca ceder soberanía.
11. Nadie habla por Bitcoin; la evidencia habla por sí misma.
12. Ninguna propuesta sin deliberación.
13. Ninguna ejecución sin auditoría.
14. Ninguna reputación sin evidencia.
15. Ninguna delegación sin revocación.
16. El consenso bruto debe permanecer visible.
17. El consenso ponderado debe declarar su método.
18. Las preocupaciones minoritarias deben preservarse.
19. El almacenamiento no es autoridad.
20. La verificabilidad es autoridad.
21. **La ley gobierna al código.** Todo código institucional es reversible, actualizable e impugnable.
22. **Automatizar procedimientos no es automatizar soberanía.**
23. **La soberanía tecnológica pertenece a la comunidad.** Ningún componente es insustituible; los datos son siempre exportables.
24. **Descentralizar infraestructura no es descentralizar poder.** El poder se mide, no se presume.
25. **Algunas cosas no se convierten en código:** la empatía, la excepción, la negociación, la justicia, la responsabilidad y la capacidad de cambiar de opinión.

</details>

## Licencias

Usamos el mismo esquema de licencias que [Decidim](https://docs.decidim.org/en/v0.31/whitepaper/what-is-decidim), la plataforma de participación de código abierto: lo que se comparte y se mejora sigue siendo de todos.

| Qué | Licencia | En pocas palabras |
| --- | --- | --- |
| **Código** | [GNU AGPL v3](https://www.gnu.org/licenses/agpl-3.0.html) | Puedes usarlo, cambiarlo y redistribuirlo. Si lo ofreces como servicio en internet, compartes tus cambios con la misma licencia. |
| **Contenido** (textos, imágenes, diseño) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.es) | Puedes copiarlo y adaptarlo citando a OpenCivic y compartiendo con la misma licencia. |
| **Datos abiertos** | [ODbL 1.0](https://opendatacommons.org/licenses/odbl/) | Puedes usar y adaptar las bases de datos citando la fuente y manteniendo abiertas las versiones derivadas. |

El logo y el nombre de OpenCivic identifican a la organización: puedes mostrarlos para referirte a nosotros, pero no para hacerte pasar por nosotros. Detalle en [`LICENSE.md`](LICENSE.md).

## Confianza

- **Canales oficiales:** solo los que figuran en el sitio web de OpenCivic. Si un mensaje o un video aparece fuera de ellos, no es nuestro.
- **IA declarada:** todo contenido generado o asistido por IA se etiqueta, y todo clon digital figura en un registro público con el consentimiento de la persona.
- **Imparcialidad:** criticamos con la misma vara al Estado, al capital, a la mayoría y a la utopía tecnológica. No hacemos propaganda partidaria.
- **Seguridad:** para reportar una vulnerabilidad o una suplantación, escribe a [info@opencivicsolutions.org](mailto:info@opencivicsolutions.org).

<img src="assets/divisor.svg" width="100%" alt="">

<p align="center">
  <img src="assets/opencivic-icono-color.svg" width="56" alt="Símbolo de OpenCivic"><br>
  <sub>OpenCivic Solutions · <a href="https://opencivicsolutions.org">opencivicsolutions.org</a> · código <a href="LICENSE.md">AGPL-3.0</a> · contenido <a href="LICENSE.md">CC BY-SA 4.0</a> · datos <a href="LICENSE.md">ODbL</a></sub>
</p>
